$(document).ready(function(){
    $.ajax({
      url: "http://localhost/sidora/functions1.php",
      method: "GET",
      success: function(data) {
        console.log(data);
        var golDrh = [];
        var jumlah = [];

        for(var i in data) {
          golDrh.push("Golongan Darah " + data[i].gol_darah);
          jumlah.push(data[i].totalDarah);
        }
        var chartdata = {
          labels: golDrh,
          datasets : [
              {
                  label: 'Jumlah Kantung Darah',
                  backgroundColor: 'rgba(255, 180, 0, 0.7)',
                  borderColor: 'rgba(255, 180, 0, 0.7)',
                  hoverBackgroundColor: 'rgba(255, 180, 150, 1)',
                  hoverBorderColor: 'rgba(255, 180, 150, 1)',
                  data: jumlah
              }
          ]
        };

        var ctx = document.getElementById("barChart");

        var barGraph = new Chart(ctx, {
            type: 'bar',
            data: chartdata
        });
      },
      error: function(data) {
        console.log(data);
      }
    });
    
  });

$(document).ready(function(){
    $.ajax({
      url: "http://localhost/sidora/functions1.php",
      method: "GET",
      success: function(data) {
        console.log(data);
        var golDrh = [];
        var jumlah = [];

        for(var i in data) {
          golDrh.push("Golongan Darah " + data[i].gol_darah);
          jumlah.push(data[i].totalDarah);
        }
        var chartdata = {
          labels: golDrh,
          datasets : [
              {
                  label: 'Jumlah Kantung Darah',
                  backgroundColor : ["#DEB887", "#A9A9A9", "#DC143C", "#F4A460"],
                  borderColor : ["#CDA776", "#989898", "#CB252B", "#E39371"],
                  borderWidth : [1, 1, 1, 1],
                  data: jumlah
              }
          ]
        };

        var ctx = document.getElementById("pieChart");

        var pieGraph = new Chart(ctx, {
            type: 'pie',
            data: chartdata
        });
      },
      error: function(data) {
        console.log(data);
      }
    });
    
  });

$(document).ready(function(){
    $.ajax({
      url: "http://localhost/sidora/functions2.php",
      method: "GET",
      success: function(data) {
        console.log(data);
        var lokasi = [];
        var prfrdLoc = [];

        for(var i in data) {
          lokasi.push(data[i].lokasi);
          prfrdLoc.push(data[i].prfrdLoc);
        }
        var chartdata = {
          labels: lokasi,
          datasets : [
              {
                  label: 'Total Lokasi Dipilih',
                  backgroundColor: 'rgba(255, 90, 0, 0.7)',
                  borderColor: 'rgba(255, 90, 0, 0.7)',
                  borderWidth : 1,
                  hoverBackgroundColor: 'rgba(255, 90, 100, 1)',
                  hoverBorderColor: 'rgba(255, 90, 100, 1)',
                  data: prfrdLoc
              }
          ]
        };


        var ctx = document.getElementById("barChart1");

        var barGraph = new Chart(ctx, {
            type: 'bar',
            data: chartdata,
        });
      },
      error: function(data) {
        console.log(data);
      }
    });
    
  });

$(document).ready(function(){
    $.ajax({
      url: "http://localhost/sidora/functions2.php",
      method: "GET",
      success: function(data) {
        console.log(data);
        var lokasi = [];
        var prfrdLoc = [];

        for(var i in data) {
          lokasi.push(data[i].lokasi);
          prfrdLoc.push(data[i].prfrdLoc);
        }
        var chartdata = {
          labels: lokasi,
          datasets : [
              {
                  label: 'Lokasi Donor yang Lebih Diminati',
                  backgroundColor : ["#F4A460", "#DC143C"],
                  borderColor : ["#E39371", "#CB252B"],
                  borderWidth : [1, 1, 1, 1],
                  data: prfrdLoc
              }
          ]
        };

        var ctx = document.getElementById("pieChart1");

        var pieGraph = new Chart(ctx, {
            type: 'pie',
            data: chartdata
        });
      },
      error: function(data) {
        console.log(data);
      }
    });
    
  });