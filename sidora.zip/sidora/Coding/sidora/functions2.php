<?php
header('Content-Type: application/json');

$conn = mysqli_connect("localhost:3307", "root", "", "blood_bank");

if (!$conn) {
	// code...
	die("Conection failed: " . $conn->error);
}

	$query = sprintf("SELECT lokasi, COUNT(lokasi) 'prfrdLoc' FROM pendonor_darah GROUP BY lokasi ORDER BY lokasi ASC");
		$result = $conn->query($query);
		$data = array();
		foreach ($result as $row) {
			// code...
			$data[] = $row;
		}
		$result->close();


		print json_encode($data);

?>