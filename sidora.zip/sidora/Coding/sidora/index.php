<?php 

require 'functions.php';

// mengecheck apakah tombol submit telah dipencet atau belum
if(isset($_POST["submit"]) ) {
  // mencheck apakah data berhasil diupdate atau tidak
    if( tambahData($_POST) > 0 ) {
      echo "
      <script>
        alert('Your appointment request has been sent successfully. Thank you!');
        document.location.href = 'index.php';
      </script>
        ";
    } else {
      echo "
      <script>
        alert('Your appointment request are failed to be sent, please fill the required forms');
        document.location.href = 'index.php';
      </script>
      ";
    }

  };

 ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Sidora</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Medilab - v4.3.0
  * Template URL: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-between">
      <div class="contact-info d-flex align-items-center">
      </div>
      <div class="d-none d-lg-flex social-links align-items-center">
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="index.html">Sidora</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li class="dropdown"><a href="#"><span>Menu</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#stok-darah">Stok Darah</a></li>
              <li><a href="#rs-terdekat">RS Terdekat</a></li>
              <li><a href="#riwayat">Riwayat</a></li>
              <li><a href="#statistik">Statistik</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="#contact">Kontak</a></li>
          <li><a class="nav-link scrollto" href="#info">Info</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <a href="#donor" class="appointment-btn scrollto"><span class="d-none d-md-inline">Daftar</span>Donor</a>

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container">
      <h1>Selamat Datang di Sidora</h1>
      <h2>Jangan Takut Untuk Donor Darah, Mereka Membutuhkanmu</h2>
      <!--
      <a href="#about" class="btn-get-started scrollto">Get Started</a>
    -->
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us">
      <div class="container">

        <div class="row">
          <div class="col-lg-4 d-flex align-items-stretch">
            <div class="content">
              <h3>Mengapa sidora?</h3>
              <p>
                Sidora adalah layanan donor darah bagi masyarakat di kota Yogyakarta. Keunggulan dari sidora adalah memberikan berbagai macam paket untuk melakukan donor darah ataupun bagi yang memebutuhkan darah dimana kami juga menawarkan jasa ke rumah sehingga masyarakat tidak perlu repot-repot ke rumah sakit/palang merah 
              </p>
            </div>
          </div>

          <div id="riwayat">
          <div class="col-lg-8 d-flex align-items-stretch">
            <div class="icon-boxes d-flex flex-column justify-content-center">
              <div class="row">
                <div class="section-title">
                <h2>Riwayat</h2>
                </div>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-receipt"></i>
                    <h4>Golongan Darah</h4>
                    <p></p>
                  </div>
                </div>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-cube-alt"></i>
                    <h4>Jumlah Donor</h4>
                    <p></p>
                  </div>
                </div>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-images"></i>
                    <h4>Donor Selanjutnya</h4>
                    <p></p>
                  </div>
                </div>
              </div>
            </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End Why Us Section -->

    <!-- ======= Counts Section ======= -->
    <section id="stok-darah" class="stok-darah">
      <div class="container">

        <div class="row">
          <div class="section-title">
          <h2>Stok Darah</h2>
        </div>
          <br>
          <div class="col-lg-3 col-md-6">
            <div class="count-box">
              <i class="fas fa-user-md"></i>
              <span data-purecounter-start="0" data-purecounter-end="2" data-purecounter-duration="1" class="purecounter"></span>
              <p>A</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-md-0">
            <div class="count-box">
              <i class="far fa-hospital"></i>
              <span data-purecounter-start="0" data-purecounter-end="2" data-purecounter-duration="1" class="purecounter"></span>
              <p>AB</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="fas fa-flask"></i>
              <span data-purecounter-start="0" data-purecounter-end="4" data-purecounter-duration="1" class="purecounter"></span>
              <p>B</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="fas fa-award"></i>
              <span data-purecounter-start="0" data-purecounter-end="2" data-purecounter-duration="1" class="purecounter"></span>
              <p>O</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Counts Section -->

    <!-- ======= Services Section ======= -->
    <section id="rs-terdekat" class="rs-terdekat">
      <div class="container">

        <div class="section-title">
          <h2>Rumah Sakit Terdekat</h2>
          <p></p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="icon-box">
              <div class="icon"><i class="fas fa-heartbeat"></i></div>
              <h4><a href="">Rumah Sakit Jogja International</a></h4>
              <p></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0">
            <div class="icon-box">
              <div class="icon"><i class="fas fa-pills"></i></div>
              <h4><a href="">Rumah Sakit Bethesda </a></h4>
              <p></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0">
            <div class="icon-box">
              <div class="icon"><i class="fas fa-hospital-user"></i></div>
              <h4><a href="">Rumah Sakit Sardjito</a></h4>
              <p></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4">
            <div class="icon-box">
              <div class="icon"><i class="fas fa-dna"></i></div>
              <h4><a href="">Rumah Sakit PKU Muhammadiyah</a></h4>
              <p></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4">
            <div class="icon-box">
              <div class="icon"><i class="fas fa-wheelchair"></i></div>
              <h4><a href="">Rumah Sakit Panti Rapih</a></h4>
              <p></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4">
            <div class="icon-box">
              <div class="icon"><i class="fas fa-notes-medical"></i></div>
              <h4><a href="">Rumah Sakit Hidayatullah</a></h4>
              <p></p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->


<!-- ======= Appointment Section ======= -->
    <section id="donor" class="donor section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Ayo donor darah sekarang!</h2>
          <p></p>
        </div>

        <form action="" method="POST">
          <div class="row">
            <div class="col-md-4 form-group">
              <label for="nama"> Nama Lengkap</label>
              <input type="text" name="nama" class="form-control" id="nama" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
              <div class="validate"></div>
            </div>
            <div class="col-md-4 form-group mt-3 mt-md-0">
              <label for="email"> Masukkan Email</label>
              <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="minlen:4" data-msg="Please enter a valid email">
              <div class="validate"></div>
            </div>
            <div class="col-md-4 form-group mt-3 mt-md-0">
              <label for="phone"> Phone Number</label>
              <input type="text" class="form-control" name="phone" id="phone" placeholder="Your Phone" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
              <div class="validate"></div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 form-group mt-3">
              <label for="tanggal_periksa"> Atur Tanggal</label>
              <input type="date" name="tanggal_periksa" class="form-control datepicker" id="tanggal_periksa" placeholder="Tanggal Janji" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
              <div class="validate"></div>
            </div>

            <div class="col-md-4 form-group mt-3">
              <label for="gender"> Jenis Kelamin</label>
              <select name="gender" id="gender" class="form-select" required>
                <option value="0">---Pilih Salah Satu---</option>                
                <option value="Perempuan">Perempuan</option>
                <option value="Laki-laki">Laki-laki</option>
              </select>
              <div class="validate"></div>
            </div>

            <div class="col-md-4 form-group mt-3 ">
              <label for="gol_darah"> Gol Darah</label>
              <select name="gol_darah" id="gol_darah" class="form-select" required>
                <option value="0">---Pilih Salah Satu---</option>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="O">O</option>
                <option value="AB">AB</option>
              </select>
              </div>
              <div class="col-md-4 form-group mt-3">
              <label for="keperluan"> Keperluan</label>
              <select name="keperluan" id="keperluan" class="form-select" required>
                <option value="0">---Pilih Salah Satu---</option>
                <option value="Donor">Donor</option>
                <option value="Butuh">Butuh</option>
              </select>
              <div class="validate"></div>
            </div>
        
           <div class="col-md-4 form-group mt-3 ">
              <label for="lokasi"> Lokasi Donor</label>
              <select name="lokasi" id="lokasi" class="form-select" required>
                <option value="0">---Pilih Salah Satu---</option>
                <option value="Rumah">Rumah</option>
                <option value="Rumah Sakit">Rumah Sakit</option>
              </select>
            </div>
            <div class="col-md-4 form-group mt-3">
              <label for="alamat"> Alamat</label>
              <input type="text" name="alamat" class="form-control" id="alamat" placeholder="Your Address" data-rule="minlen:4" data-msg="Address">
              <div class="validate"></div>
            </div>
            <div class="col-md-4 form-group mt-3">
              <label for="no_ktp"> No KTP</label>
              <input type="text" name="no_ktp" class="form-control" id="no_ktp" placeholder="No KTP" data-rule="minlen:4" data-msg="Masukkan No KTP">
              <div class="validate"></div>
            </div>
          <div class="form-group mt-3">
            <label for="message"> Pesan(opsional)</label>
            <textarea class="form-control" name="message" rows="5" id="message" placeholder="Message (Optional)"></textarea>
            <div class="validate"></div>
          </div>
          <div class="text-center"><button type="submit" name="submit">Buat Janji</button></div>
        </form>

      </div>
    </section><!-- End Appointment Section -->

    <!-- ======= Departments Section ======= -->
    <section id="info" class="info">
      <div class="container">

        <div class="section-title">
          <h2>Informasi</h2>
          <p>Informasi penting yang harus diperhatikan sebelum Donor Darah.</p>
        </div>

        <div class="row">
          <div class="col-lg-3">
            <ul class="nav nav-tabs flex-column">
              <li class="nav-item">
                <a class="nav-link active show" data-bs-toggle="tab" href="#tab-1">Syarat Untuk Mendonor Darah</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-2">Hindari donor darah jika</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-3">Panduan untuk donor darah</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-4">Kriteria PMI</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-5">Cara menentukan waktu donor darah</a>
              </li>
            </ul>
          </div>
          <div class="col-lg-9 mt-4 mt-lg-0">
            <div class="tab-content">
              <div class="tab-pane active show" id="tab-1">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Syarat Untuk Mendonor Darah</h3>
                    <p class="fst-italic">Salaah satu kegiatan PMI yang paling dikenali masyarakat adalah donor darah. Menyumbangkan sebagian darah untuk kemudian disalurkan kepada yang membutuhkan menjadi suatu sumbangan berarti dalam kehidupan sosial bermasyarakat. Tidak Membutuhkan persyaratan sulit untuk menjadi calon donor.</p>
                    <p>Donor darah adalah orang yang memberikan darah secara sukarela untuk maksud dan tujuan transfusi darah bagi orang lain yang membutuhkan. Semua orang dapat menjadi donor darah jika memenuhi persyaratan yang berlaku.</p>
                    <p>APA SYARAT-SYARAT UNTUK MENJADI DONOR DARAH?</p>
                    <p><ol>
                      <li>Sehat jasmani dan rohani</li>
                      <li>Usia 17 sd 65 tahun</li>
                      <li>Berat badan min 45 kg</li>
                      <li>Tekanan darah 
                        <ul>
                          <li>Sistole 100-170</li>
                          <li>Diastole 70-100</li>
                        </ul></li>
                        <li>Kadar hemoglogin 12,5g% s/d 17,0g%</li>
                        <li>Interval donor minimal 12 minggu atau 3 bulan sejak donor darah sebelumnya (maksimal 5 kali dalam 2 tahun)</li>
                    </p></h5>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/departments-1.jpg" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-2">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Hindari donor darah jika</h3>
                    <p>
                      <ol>
                        <li>Mempunyai penyakit jantung dan paru-paru</li>
                        <li>Menderita kanker</li>
                        <li>Mendeerita tekanan darah tinggai</li>
                        <li>Menderita kencing manis</li>
                        <li>Memiliki kecenderungan pendarahan abnormal atau kelainan darah lainnya</li>
                        <li>Menderita epilepsi dan sering kejang</li>
                        <li>Menderita atau pernah menderita hepatitis B atau C</li>
                        <li>Mengidap sifilis</li>
                        <li>Ketergantungan narkoba</li>
                        <li>Kecanduan minuman beralkohol</li>
                        <li>Mengidap atau beresiko tinggi terhadap HIV/AIDS</li>
                        <li>Dokter menyarakan untuk tidak menyumbangkan darah karena alasan kesehatan</li>
                      </ol>
                    </p>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/departments-2.jpg" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-3">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Panduan untuk donor darah</h3>
                    <p>
                      <ol>
                        <li>Tidur minimal 4 jam sebelum donor</li>
                        <li>Makan 3-4 jam sebelum menyumbangkan darah, jangan menyumbangkan darah dengan perut kosong</li>
                        <li>Minum lebih banyak dari biasanya pada hari mendonorkan darah(paling sedikit 3 gelas)</li>
                        <li>Setelah donor beristirahat paling sedikit 10 menit sambil menikmati makanan donor, sebelum kembali beraktifitas</li>
                        <li>Kembali bekerja setelah donor darah tidak berbahaya untuk kesehatan</li>
                        <li>Untuk menghindari bengkak di lokasi bengkak jarum, hindari mengangkat benda berat selama 12 jam</li>
                        <li>Banyak minum sampai 72 jam ke depan untuk mengembalikan stamina</li>

                      </ol>
                    </p>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/departments-3.jpg" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-4">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Kriteria PMI</h3>
                    <p>
                      <ul>
                        <li>Calon donor harus berusia 15-60 tahun</li>
                        <li>Berat badan minimal 45 kg</li>
                        <li>Tekanan darah 100-180 (sistole) dan 60-100 (diastole)</li>
                        <li>Jika berminat, calon donor dapat mengambil dan menandatangani formulir pendaftaran, lalu menjalani pemeriksaan pendahuluan seperti kondisi BB, HB, gol darah, serta dilanjutkan dengan pemeriksaan dokter</li>
                        <li>Jika lulus, barulah darah dan contoh darah diambil</li>
                        <li>Namun, harus diingat, demi manjaga kesehatan dan keamanan darah, individu yang antara lain memiliki kondisi seperti alkoholik, penyakit hepatitis, diabetes militus, epilepsi, atau kelompok masyarakat resiko tinggi mendapatkan AIDS serta mengalami sakit seperto demam atau influenza, baru saja dicabut giginya kurang dari 3 hari, pernah menerima transfusi kurang dari setahun, begitu juga untuk yang belum setahun mentato, menindik, atau akupunktur, hamil, atau sedang menyusui untuk sementara waktu tidak dapat menjadi donor</li>

                      </ul>
                    </p>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/departments-4.jpg" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-5">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Est eveniet ipsam sindera pad rone matrelat sando reda</h3>
                    <p class="fst-italic">Omnis blanditiis saepe eos autem qui sunt debitis porro quia.</p>
                    <p>Exercitationem nostrum omnis. Ut reiciendis repudiandae minus. Omnis recusandae ut non quam ut quod eius qui. Ipsum quia odit vero atque qui quibusdam amet. Occaecati sed est sint aut vitae molestiae voluptate vel</p>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/departments-5.jpg" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Departments Section -->

    <!-- ======= Doctors Section ======= -->
    <section id="statistik" class="doctors">
      <div class="container">

        <div class="section-title">
          <h2>Statistik</h2>
          <p></p>
        </div>

        <div class="row">

          <div class="col-lg-6">
            <div class="member d-flex align-items-start">
              <a href="grafik_pasokan_darah.html"><div class="pic"><img src="assets/img/icon/stok-darah.png" class="img-fluid" alt="">
                </div></a>
              <div class="member-info">
                <h4>Bank Darah</h4>
              </div>
            </div>
          </div>
          
            
          <div class="col-lg-6 mt-4 mt-lg-0">
            <div class="member d-flex align-items-start">
              <a href="grafik_peminatan_lokasi.html">
              <div class="pic"><img src="assets/img/icon/donor.png" class="img-fluid" alt=""></div>
              </a>
              <div class="member-info">
                <h4>Lokasi Donor yang Diminati</h4>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Doctors Section -->


    <!-- ======= Testimonials Section ======= -->

            <div class="swiper-slide d-flex align-items-center justify-content-center">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt="">
                  <h3>Painem</h3>
                  <h4>Tukang Sayur Gang Sebelah</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Mantep aplikasi iki bisa nulung aku mempermudah donor darah ning omah
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            -->
            </div><!-- End testimonial item -->

    </section><!-- End Testimonials Section -->



    <!-- ======= Contact Section ======= -->

    <section id="contact" class="contact">
          <div class="col-lg-8 mt-5 mt-lg-0">

            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          <strong><span>Sidora.com</span></strong>
        </div>
        <div class="credits">
          Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
        </div>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script type="text/javascript" src="assets/js/main.js"></script>
</body>



</html>

