<?php 
	$conn = mysqli_connect("localhost:3307", "root", "", "blood_bank");

	function query($query) {
		global $conn;

		$result = mysqli_query($conn, $query);
		$rows = [];
		while( $row = mysqli_fetch_assoc($result) ) {
			$rows[] = $row;
			
		}
		return $rows;
	}

	function tambahData($POST) {
		global $conn;

		// mengambil data dari tiap elemen data form
		$nama = htmlspecialchars($POST["nama"]);
		$email = htmlspecialchars($POST["email"]);
		$phone = htmlspecialchars($POST["phone"]);
		$tanggal_periksa = htmlspecialchars($POST["tanggal_periksa"]);
		$gender = htmlspecialchars($POST["gender"]);
		$gol_darah = htmlspecialchars($POST["gol_darah"]);
		$keperluan = htmlspecialchars($POST["keperluan"]);
		$lokasi = htmlspecialchars($POST["lokasi"]);
		$alamat = htmlspecialchars($POST["alamat"]);
		$no_ktp = htmlspecialchars($POST["no_ktp"]);
		$message = htmlspecialchars($POST["message"]);


		// query insert data
		$query = "INSERT INTO pendonor_darah 
					VALUES 
					('', '$nama', '$email', '$phone', '$tanggal_periksa', '$gender', '$gol_darah', 
					 '$keperluan', '$lokasi', '$alamat', '$no_ktp', '$message')";
		mysqli_query($conn, $query);

		return mysqli_affected_rows($conn);
	}

	
	
?>