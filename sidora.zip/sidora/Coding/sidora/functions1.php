<?php 
header('Content-Type: application/json');

$conn = mysqli_connect("localhost:3307", "root", "", "blood_bank");

if (!$conn) {
	// code...
	die("Conection failed: " . $conn->error);
}

$query = sprintf("SELECT gol_darah, COUNT(gol_darah) 'totalDarah' FROM pendonor_darah GROUP BY gol_darah ORDER BY gol_darah ASC");
		$result = $conn->query($query);
		$data = array();
		foreach ($result as $row) {
			// code...
			$data[] = $row;
		}
		$result->close();


		print json_encode($data);

// $query1 = sprintf("SELECT lokasi, COUNT(lokasi) 'pfrdLoc' FROM pendonor_darah GROUP BY lokasi ORDER BY lokasi ASC");
// 		$result1 = $conn->query($query1);
// 		$data1 = array();
// 		foreach ($result1 as $row) {
// 			// code...
// 			$data1[] = $row;
// 		}
// 		$result1->close();


// 		print json_encode($data1);

 ?>

