-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jul 18, 2021 at 05:49 PM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blood_bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `kntng_drh_rs`
--

CREATE TABLE `kntng_drh_rs` (
  `golongan_darah` varchar(3) NOT NULL,
  `jumlah_kantung` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kntng_drh_rs`
--

INSERT INTO `kntng_drh_rs` (`golongan_darah`, `jumlah_kantung`) VALUES
('A', 2),
('AB', 2),
('B', 4),
('O', 2);

-- --------------------------------------------------------

--
-- Table structure for table `lokasi_rs`
--

CREATE TABLE `lokasi_rs` (
  `id` int(4) NOT NULL,
  `alamat` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pendonor_darah`
--

CREATE TABLE `pendonor_darah` (
  `id` int(11) NOT NULL,
  `nama` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL,
  `tanggal_periksa` date DEFAULT NULL,
  `gender` varchar(200) DEFAULT NULL,
  `gol_darah` varchar(4) DEFAULT NULL,
  `keperluan` varchar(100) DEFAULT NULL,
  `lokasi` varchar(100) DEFAULT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `no_ktp` varchar(100) DEFAULT NULL,
  `message` varchar(800) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pendonor_darah`
--

INSERT INTO `pendonor_darah` (`id`, `nama`, `email`, `phone`, `tanggal_periksa`, `gender`, `gol_darah`, `keperluan`, `lokasi`, `alamat`, `no_ktp`, `message`) VALUES
(1, 'Muhammad Zaki Muflih Tri Shafwan', '19523084@students.uii.ac.id', '085643504463', '2021-07-07', 'Laki-laki', 'O', 'Donor', 'Rumah', 'jl. Ngasem No.6', '09877689998766544567', ''),
(2, 'Khoiri Rochmanila', '19523142@students.uii.ac.id', '0810980098789', '2021-07-08', 'Perempuan', 'O', 'Donor', 'Rumah', 'jl. kasuari No.7', '095849850880989099', ''),
(3, 'Fatima Shalehah', '19523229@students.uii.ac.id', '087654665412', '2021-07-06', 'Perempuan', 'B', 'Donor', 'Rumah', 'jl. mangga No.8', '78172863671789923123', ''),
(4, 'Azka Nabilah Auliyaurrohman', '19523226@students.uii.ac.id', '08198765678', '2021-07-09', 'Perempuan', 'B', 'Donor', 'Rumah', 'jl. durian No.9', '808908978656777989', ''),
(5, 'Muhammad Zaki Muflih Tri Shafwan', '19523084@students.uii.ac.id', '085643504463', '2021-07-09', 'Laki-laki', 'A', 'Donor', 'Rumah Sakit', 'jl. Ngasem No.6', '09877689998766544567', ''),
(6, 'Khoiri Rochmanila', '19523142@students.uii.ac.id', '0810980098789', '2021-07-10', 'Perempuan', 'B', 'Donor', 'Rumah Sakit', 'jl. kasuari No.7', '095849850880989099', ''),
(7, 'Fatima Shalehah', '19523229@students.uii.ac.id', '087654665412', '2021-07-11', 'Perempuan', 'A', 'Donor', 'Rumah Sakit', 'jl. mangga No.8', '78172863671789923123', ''),
(8, 'Azka Nabilah Auliyaurrohman', '19523226@students.uii.ac.id', '08198765678', '2021-07-12', 'Perempuan', 'AB', 'Donor', 'Rumah Sakit', 'jl. durian No.9', '808908978656777989', ''),
(10, 'Muhammad Zaki Muflih Tri Shafwan', '19523084@students.uii.ac.id', '085643504463', '2021-07-13', 'Laki-laki', 'B', 'Donor', 'Rumah Sakit', 'jl. Ngasem No.6', '09877689998766544567', ''),
(11, 'Muhammad Zaki Muflih Tri Shafwan', '19523084@students.uii.ac.id', '085643504463', '2021-07-15', 'Laki-laki', 'AB', 'Donor', 'Rumah Sakit', 'jl. Ngasem No.6', '09877689998766544567', ''),
(13, 'Khoiri Rochmanila', '19523142@students.uii.ac.id', '0810980098789', '2021-07-18', 'Perempuan', 'O', 'Donor', 'Rumah Sakit', 'jl. mangga No.8', '095849850880989099', ''),
(14, 'Fatima Shalehah', '19523229@students.uii.ac.id', '087654665412', '2021-07-20', 'Perempuan', 'AB', 'Donor', 'Rumah Sakit', 'jl. kasuari No.7', '78172863671789923123', ''),
(15, 'Azka Nabilah Auliyaurrohman', '19523226@students.uii.ac.id', '08198765678', '2021-07-23', 'Perempuan', 'A', 'Donor', 'Rumah', 'jl. durian No.9', '808908978656777989', '');

-- --------------------------------------------------------

--
-- Table structure for table `rumah_sakit`
--

CREATE TABLE `rumah_sakit` (
  `id` int(4) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jml_drh` varchar(100) NOT NULL,
  `jml_perawat` int(4) NOT NULL,
  `id_lokasi` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kntng_drh_rs`
--
ALTER TABLE `kntng_drh_rs`
  ADD PRIMARY KEY (`golongan_darah`) USING BTREE;

--
-- Indexes for table `lokasi_rs`
--
ALTER TABLE `lokasi_rs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pendonor_darah`
--
ALTER TABLE `pendonor_darah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rumah_sakit`
--
ALTER TABLE `rumah_sakit`
  ADD PRIMARY KEY (`id`),
  ADD KEY `golongan_darah` (`jml_drh`),
  ADD KEY `id_lokasi` (`id_lokasi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pendonor_darah`
--
ALTER TABLE `pendonor_darah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rumah_sakit`
--
ALTER TABLE `rumah_sakit`
  ADD CONSTRAINT `rumah_sakit_ibfk_2` FOREIGN KEY (`id_lokasi`) REFERENCES `lokasi_rs` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
